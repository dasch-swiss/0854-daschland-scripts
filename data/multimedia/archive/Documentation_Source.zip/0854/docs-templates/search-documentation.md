# Full-Text Search 

https://docs.dasch.swiss/latest/DSP-APP/user-guide/data/search/#full-text-search

DSP offers a full-text search that searches through all text values and labels of resources based on one or several terms (or phrase) written in the search bar. It returns data that matches the search conditions.

## Filter your full-text search by specific project

By default, the search is performed in all projects stored in DSP. 
However, it is possible to filter by project using the "Filter by project" menu on the left side of the search bar.

## Search History

When clicking on the search bar, the search history panel is displayed. 
The last 10 searches are registered. Click on one search item to perform the same full-text search again. 

It is also possible to clear the search history list ("clear list" button at the bottom of the panel or the "x" at the end of each line).
Search history list is accessible for the full-text search from any webpage.

## Search Rules

A search value must have a minimum length of 3 characters. If your search term has less than three characters (e.g. *is*), please add two asterisks: *\*is\**. 

- All terms are interpreted as lowercase characters.

  E.g.: *My dearest Maria* is interpreted as *my dearest maria*.
- By default, the logical operator OR is used when submitting several search terms.
- Each term separated by a whitespace is considered a single term.
  E.g. the expression *Queen of Hearts* is searched as *queen* OR *hearts*.
  The database will return all results that include the terms *queen of hearts*, *queen*, or *hearts*.
  In this case, the search results `169` resources.
- To find an exact expression, the terms must be surrounded by quotes.
  E.g.: to find the expression *Queen of Hearts*, it must be entered as *"Queen of Hearts"*.
  The search results `10` resources.

## Special Syntax

Special characters can be used in order to search for specific text patterns. 
Here is the list of characters with special meaning: 

+, -, &&, ||, !, (, ), \[, \], {, }, ^, ", ~, *, ?, :, \, /

For more information about them, please read the Lucene documentation: 

https://lucene.apache.org/core/7_7_0/queryparser/org/apache/lucene/queryparser/classic/package-summary.html

### Most common used characters

- The asterisk * can be used as a wildcard symbol for zero, one, or multiple characters. 
  E.g. *deco*\* will yield results such as *decor*, *decoration*, *decorate*, *decorating*, etc.
- The question mark ? can be used as a wildcard symbol for a single character. 
  E.g. *Bern?* will yield results such as *Berne*, *Bernt*, etc. (but not *Bernasconi*)
- Quotation marks "" allow searches for the whole pattern. 
  E.g. *"White Rabbit"* yields a result for the exact term *White Rabbit*. 
  If your search term consists of more than one word, and you intend to do an AND search, please use quotation marks.

In order to make searching easier and independent of special characters, we recommend to use the advanced search. 
It will narrow down the search and accept special letters or characters. 

### Include special characters in the search

- If one of the above characters should be included in the search - without any special meaning - it needs to be escaped by the character \ .
  E.g. If you want to search for *cheshire-cat*, you should type *cheshire\-cat*.

## Conversion

- Alphabetic, numeric, symbolic, and diacritical Unicode characters which are not part of the first 127 ASCII characters (the "Basic Latin" Unicode block) are converted into their ASCII equivalents, if one exists. 
  If this is not what you need, please use the advanced search option instead.
  E.g. *é*, *ä*, *š* are converted into *e*, *a*, and *s*. 
  This means that a search for *šumma* will yield results for *šumma*, *summa*, *ṣumma*, *śumma*, etc. 
- For special characters that cannot be converted to ASCII equivalents, we suggest to replace the respective special character by an asterisk.
  E.g. *ṛtasya*, where the *ṛ* must be replaced either by *rr* or - simpler - by *: 
  thus searches for *rrtasya* or *\*tasya* will yield the intended search result, but not *rtasya*.

# Advanced Search

The advanced search allows you to look for a specific term or expression present in one or multiple properties. 
The property can belong to one specific class or be used in multiple classes, according to the data model. 

A query consists of the following elements:
- selection of a resource class belonging to the selected data model (optional)
- specification of properties, comparison operators, and values (optional)

Although the selection of a resource or a property or both are optional, either a resource class has to be selected or at least one property has to be specified, otherwise, the search button stays inactive.

## Sorting

Once you determined the criteria for your search, you can open the "Order by" dropdown situated at the top of the form. 
By selecting the checkbox of the property, you specify what it will be sorted by. 

The order of the entries determines which criterion should be used for sorting first. 
You can reorder them by clicking and dragging.

E.g. searching for `Characters` with a specific `Keyword` and sorting by the `Keyword` allows to sort by the subnodes of the `Keyword` you searched for. 

## Comparison Operators

Depending on the value type of the chosen property, one or more of the following comparison operators can be selected: 

### equals (value equality) 

- exact same string
- same number
- an overlap of date periods
- same target resource

E.g. looking for all `Characters` that have the `Keyword` *Fantasy* (list node) will result as all resources displaying the `Keyword` *Fantasy*, 
including the sub-nodes *Imagination*, *Surrealism*, etc. 

### does not equal (value inequality)

- not exact same string
- not same number
- no overlap of date periods
- not same target resource

E.g. looking for all `Events` that have a link to *Alice* but not to the *White Rabbit* results in a list of all `Event` resources where *Alice* appears but not the *White Rabbit*. 

### exists

- value for the given property exists

E.g. looking for all `Book Chapters` that have a `Chapter Number` will result in getting all chapters from the two stories, but not the prefaces or the poems. 

**Attention**: looking for all `Events (Adventure)` for which the boolean property `Dangerous` was checked will result `14` events, although not all of them are indeed dangerous. 
Here, `7` of the `14` events have the value set on *FALSE*, which is the reason why the search has a result. 
In order to get the resources that are `Dangerous`, you must make a search with the operator "equals" and select *TRUE* from the list. 

### does not exist

- value for the given property doesn't exist

E.g. the search for all `Locations` for which no `Image` exists will result in getting `8` resources. 

### is like (regular Expressions)

- texts that are like the search value, via regular expressions (SPARQL REGEX)

E.g. the search for all `Labels` that contains *Cheshire Cat* results `6` resources. In comparison, the search with the operator "equals" results only the one resource for which the `Label` is exactly *Cheshire Cat*.

### matches

- text property: search value matches the text (Lucene Query Parser Syntax). 
- link property: matches the specified linked resource.

E.g. looking for the term *Hatt*\* results all `Resources` that have the word *Hatter* or *Hatta* in the `Label`, which allows finding all data linked with the *Mad Hatter*, who is called differently in the two stories. 

### greater/less than (value comparison)

- number is greater than search value
- date period begins after search value

E.g. the search for all `Audio` resources which size is bigger than *10Mb* will result `2` resources. 

### Greater/less than or equal to (value equality/value comparison)

- number is equal to or greater than search value
- an overlap of date periods
- date period begins on or after search value.

E.g. the search for all `Resources` that were published until *1900* included results `6` resources. 

# Expert Search

The expert search can be more powerful than the advanced search, but requires knowing how to use the query language Gravsearch (based on SparQL and developed by the DaSCH team). 
With Gravsearch, expert users can build searches by combining text-related criteria with any other criteria. 
See https://docs.dasch.swiss/latest/DSP-APP/user-guide/data/search/?h=expert#expert-search for more info.
