
## Searching Through the DSP-API

The data underlying the project is accessible through an Application Programming Interface (API).
The API is documented according to the OpenAPI specification and a Swagger interface can
be found here: https://api.dasch.swiss/api/docs/#/.
We strongly recommend to test the queries before implementing them in production code.
All the requests are executed via HTTP, 
if you do not have a tool to execute HTTP requests the following software can be used:

- For the Command Line Interface: `cURL` (https://curl.se/) 
- With a visual interface: Postman (https://www.postman.com/downloads/)



## Project Info for Endpoints

Please note that all IRIs in the search URL **must be URL encoded**. There are many tools on the internet that will encode an URL for you.

You can find the entire ontology in json-ld by clicking on the ontology IRI.
For your convenience you can find the main project IRIs in an URL encoded format below.


- **DSP-API:** https://api.dasch.swiss
- **Shortcode:** 0854
- **Shortname:** daschland
- **Ontology `daschland`:**
    - **IRI:** https://api.dasch.swiss/ontology/0854/daschland/v2
    - **IRI URL-Escaped:** `https%3A%2F%2Fapi.dasch.swiss%2Fontology%2F0854%2Fdaschland%2Fv2`
    - **Prefix:** `https://api.dasch.swiss/ontology/0854/daschland/v2#`
    - **Prefix URL-Escaped:** `https%3A%2F%2Fapi.dasch.swiss%2Fontology%2F0854%2Fdaschland%2Fv2%23`
- **Ontology `project-metadata`:**
    - **IRI:** https://api.dasch.swiss/ontology/0854/project-metadata/v2
    - **IRI URL-Escaped:** `https%3A%2F%2Fapi.dasch.swiss%2Fontology%2F0854%2Fproject-metadata%2Fv2`
    - **Prefix:** `https://api.dasch.swiss/ontology/0854/project-metadata/v2#`
    - **Prefix URL-Escaped:** `https%3A%2F%2Fapi.dasch.swiss%2Fontology%2F0854%2Fproject-metadata%2Fv2%23`

## Fulltext Search


- **Endpoint:** `https://api.dasch.swiss/v2/search/`
- **Swagger-UI Documentation:** https://api.dasch.swiss/api/docs/#/API%20v2/getV2SearchSearchterm

This search endpoint is equivalent to the fulltext search through our APP. However, unlike the APP it does not automatically filter by project. Therefore, unless specified you will get results from all the projects on DSP. If you want to limit it to a specific project you must include the parameter `limitToProject` in all your queries. We include this parameter in all the examples below.



## Search By Resource Label


- **Endpoint:** `https://api.dasch.swiss/v2/searchbylabel/`
- **Swagger-UI Documentation:** https://api.dasch.swiss/api/docs/#/API%20v2/getV2SearchbylabelSearchterm

This endpoint is designed to conduct a fulltext search that limits itself to the resource labels. Text in other properties is excluded.



## Ontology Specific Searches


- **Endpoint:** `https://api.dasch.swiss/v2/ontologies/allentities/`
- **Swagger-UI Documentation:** https://api.dasch.swiss/api/docs/#/API%20v2/getV2OntologiesAllentitiesOntologyiri

This search endpoint limits searches to classes within one ontology. And provides the option to limit the search results systematically.



## Structured Queries with Gravsearch


- **Endpoint:** `https://api.dasch.swiss/v2/searchextended/`
- **Swagger-UI Documentation:** https://api.dasch.swiss/api/docs/#/API%20v2/getV2SearchextendedP1

Gravsearch is a query language which consists of a subset of the syntax of SPARQL - it offers the advantages of SPARQL endpoints while avoiding their drawbacks in terms of performance and security. The documentation can be found here (https://docs.dasch.swiss/latest/DSP-API/03-endpoints/api-v2/query-language/). You need to know the SPARQL syntax for being able to write more complex queries on your own!

Responses of Gravsearch contain a lot of important archival metadata. This information is normally not interesting to API users. We therefore provide a simple variant, where the response corresponds to more typical RDF data. Toget the simple response, use the simple variant of the IRIs in the query prefixes (notice `/simple/` as the second to last IRI segment in the examples below).

Prefixes for Gravsearch queries in the simple schema:

```
PREFIX knora-api: <http://api.knora.org/ontology/knora-api/simple/v2#>
PREFIX daschland <https://api.dasch.swiss/ontology/0854/daschland/simple/v2#>
PREFIX project-metadata <https://api.dasch.swiss/ontology/0854/project-metadata/simple/v2#>
```

Queries can be sent through two endpoints:

`POST https://api.dasch.swiss/v2/searchextended` with the Gravsearch query string in the body.

`GET https://api.dasch.swiss/v2/searchextended/{query}` where the query parameter is the URL-encoded Gravsearch query string.
All Gravsearch queries must follow the following basic structure:

```sparql
CONSTRUCT {
    ?chapter knora-api:isMainResource true .
} WHERE {
    ?chapter a alice:Chapter .
}
```



